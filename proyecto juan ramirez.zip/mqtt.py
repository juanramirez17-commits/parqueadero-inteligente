from umqtt.simple import MQTTClient
import json

from config import BROKER, PUERTO

cliente = None

def conectar_mqtt():
    global cliente

    try:
        cliente = MQTTClient(
            "parqueadero_esp32_juan",
            BROKER,
            port=PUERTO
        )

        cliente.connect()
        print("Conectado al servidor MQTT")
        return True

    except Exception as error:
        print("Error MQTT:", error)
        cliente = None
        return False


def enviar_datos(estados):
    global cliente

    if cliente is None:
        return False

    try:
        ocupados = 0
        disponibles = 0

        for espacio, estado in estados.items():

            if estado == "OCUPADO":
                ocupados += 1

            elif estado == "DISPONIBLE":
                disponibles += 1

            datos = {
                "estado": estado
            }

            tema = "parqueadero/" + espacio

            cliente.publish(
                tema,
                json.dumps(datos)
            )

        resumen = {
            "ocupados": ocupados,
            "disponibles": disponibles,
            "total": 3
        }

        cliente.publish(
            "parqueadero/estado_general",
            json.dumps(resumen)
        )

        return True

    except Exception as error:
        print("Error enviando datos:", error)
        cliente = None
        return False