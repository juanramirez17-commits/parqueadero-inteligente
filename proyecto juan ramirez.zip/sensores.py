from machine import Pin, time_pulse_us
import time

from config import TRIG1, ECHO1
from config import TRIG2, ECHO2
from config import TRIG3, ECHO3
from config import DISTANCIA_LIMITE

# Configurar los sensores
trig1 = Pin(TRIG1, Pin.OUT)
echo1 = Pin(ECHO1, Pin.IN)

trig2 = Pin(TRIG2, Pin.OUT)
echo2 = Pin(ECHO2, Pin.IN)

trig3 = Pin(TRIG3, Pin.OUT)
echo3 = Pin(ECHO3, Pin.IN)

# Medir distancia
def medir_distancia(trig, echo):
    trig.value(0)
    time.sleep_us(2)

    trig.value(1)
    time.sleep_us(10)
    trig.value(0)

    tiempo = time_pulse_us(echo, 1, 30000)

    if tiempo < 0:
        return None

    distancia = (tiempo * 0.0343) / 2
    return distancia

# Revisar los tres espacios
def revisar_parqueadero():
    espacio1 = medir_distancia(trig1, echo1)
    espacio2 = medir_distancia(trig2, echo2)
    espacio3 = medir_distancia(trig3, echo3)

    return {
        "espacio1": espacio1,
        "espacio2": espacio2,
        "espacio3": espacio3
    }

# Saber si está ocupado o disponible
def estado_espacio(distancia):
    if distancia is None:
        return "SIN_LECTURA"
    elif distancia <= DISTANCIA_LIMITE:
        return "OCUPADO"
    else:
        return "DISPONIBLE"