import network
import time

from config import SSID, PASSWORD

def conectar_wifi():
    wifi = network.WLAN(network.STA_IF)
    wifi.active(True)

    if not wifi.isconnected():
        print("Conectando al WiFi...")
        wifi.connect(SSID, PASSWORD)

        intentos = 0

        while not wifi.isconnected() and intentos < 20:
            time.sleep(1)
            intentos += 1

    if wifi.isconnected():
        print("WiFi conectado")
        print("Direccion IP:", wifi.ifconfig()[0])
        return True
    else:
        print("No se pudo conectar al WiFi")
        return False