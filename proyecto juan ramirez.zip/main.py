import time

from sensores import revisar_parqueadero, estado_espacio
from wifi import conectar_wifi
from mqtt import conectar_mqtt, enviar_datos

print("SISTEMA DE PARQUEADERO INTELIGENTE")

# Conectar al WiFi
while not conectar_wifi():
    print("Intentando conectar otra vez...")
    time.sleep(3)

# Conectar al servidor MQTT
while not conectar_mqtt():
    print("Intentando conectar MQTT...")
    time.sleep(3)

# Funcion principal
while True:

    distancias = revisar_parqueadero()

    estados = {}

    print("\n--- ESTADO DEL PARQUEADERO ---")

    for espacio, distancia in distancias.items():

        estado = estado_espacio(distancia)
        estados[espacio] = estado

        print(espacio, ":", estado)

        if distancia is not None:
            print("Distancia:", round(distancia, 2), "cm")

    # Enviar informacion por MQTT
    if not enviar_datos(estados):
        print("Reconectando MQTT...")

        conectar_wifi()
        conectar_mqtt()

    time.sleep(2)