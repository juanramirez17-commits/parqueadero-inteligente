TRIG1 = 5
ECHO1 = 34

TRIG2 = 18
ECHO2 = 35

TRIG3 = 19
ECHO3 = 32

DISTANCIA_LIMITE = 10

SSID = "Wokwi-GUEST"
PASSWORD = ""

BROKER = "test.mosquitto.org"
PUERTO = 1883